
<?php $__env->startPush('styles'); ?>
<link href="<?php echo e(asset('assets/libs/swiper/swiper-bundle.min.css')); ?>" rel="stylesheet" type="text/css" />

<?php $__env->stopPush(); ?>
<?php $__env->startSection( 'content'); ?>
      <!-- start page title -->
    <div class="main-content">

        <div class="page-content">
            <div class="container-fluid">
                <div class="row">
                    <div class="col-12">
                        <div class="page-title-box d-sm-flex align-items-center justify-content-between bg-galaxy-transparent">
                            <h4 class="mb-sm-0">Product Details</h4>

                            <div class="page-title-right">
                                <ol class="breadcrumb m-0">
                                    <li class="breadcrumb-item"><a href="javascript: void(0);">Ecommerce</a></li>
                                    <li class="breadcrumb-item active">Products</li>
                                </ol>
                            </div>

                        </div>
                    </div>
                </div>
                 <!-- end page title -->

                   <!-- start blog -->
     <section class="section" id="blog">
        <div class="container">
            <div class="row justify-content-center">
                <div class="col-lg-8">
                    <div class="text-center ">
                        <h1 class="mb-3 ff-secondary fw-semibold text-capitalize lh-base">Our Latest <span
                                class="text-primary">Products</span></h1>
                        
                    </div>
                </div>
            </div>
            <!-- end row -->

            <div class="row">
                <div class="col-lg-3 col-md-6">
                    <a href="<?php echo e(route('product.details')); ?>">
                        <div class="card">
                            <img class="card-img-top img-fluid" src="assets/images/small/img-1.jpg" alt="Card image cap">
                            <div class="card-body">
                                <h4 class="card-title mb-2">Laptop</h4>
                                <a href="#" class="text-primary d-block">Tommy Hilfiger</a>
                                <div class="d-flex flex-wrap gap-2 align-items-center mt-1">
                                    <div class="text-muted fs-16">
                                        <span class="mdi mdi-star text-warning"></span>
                                        <span class="mdi mdi-star text-warning"></span>
                                        <span class="mdi mdi-star text-warning"></span>
                                        <span class="mdi mdi-star text-warning"></span>
                                        <span class="mdi mdi-star text-warning"></span>
                                    </div>
                                    
                                </div>
                                <div class="d-flex justify-content-between">
                                    <h5 class="" class="mb-0">$120.40</h5>
                                    <div class="text-end" >

                                        <a href="<?php echo e(route('cart')); ?>" class="btn btn-primary"><i class="bx bx-shopping-bag fs-22"></i></a>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </a>
                </div>
                <div class="col-lg-3 col-md-6">
                    <a href="<?php echo e(route('product.details')); ?>">
                        <div class="card">
                            <img class="card-img-top img-fluid" src="assets/images/small/img-1.jpg" alt="Card image cap">
                            <div class="card-body">
                                <h4 class="card-title mb-2">Laptop</h4>
                                <a href="#" class="text-primary d-block">Tommy Hilfiger</a>
                                <div class="d-flex flex-wrap gap-2 align-items-center mt-1">
                                    <div class="text-muted fs-16">
                                        <span class="mdi mdi-star text-warning"></span>
                                        <span class="mdi mdi-star text-warning"></span>
                                        <span class="mdi mdi-star text-warning"></span>
                                        <span class="mdi mdi-star text-warning"></span>
                                        <span class="mdi mdi-star text-warning"></span>
                                    </div>
                                    
                                </div>
                                <div class="d-flex justify-content-between">
                                    <h5 class="" class="mb-0">$120.40</h5>
                                    <div class="text-end" >

                                        <a href="<?php echo e(route('cart')); ?>" class="btn btn-primary"><i class="bx bx-shopping-bag fs-22"></i></a>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </a>
                </div>
                <div class="col-lg-3 col-md-6">
                    <a href="<?php echo e(route('product.details')); ?>">
                        <div class="card">
                            <img class="card-img-top img-fluid" src="assets/images/small/img-1.jpg" alt="Card image cap">
                            <div class="card-body">
                                <h4 class="card-title mb-2">Laptop</h4>
                                <a href="#" class="text-primary d-block">Tommy Hilfiger</a>
                                <div class="d-flex flex-wrap gap-2 align-items-center mt-1">
                                    <div class="text-muted fs-16">
                                        <span class="mdi mdi-star text-warning"></span>
                                        <span class="mdi mdi-star text-warning"></span>
                                        <span class="mdi mdi-star text-warning"></span>
                                        <span class="mdi mdi-star text-warning"></span>
                                        <span class="mdi mdi-star text-warning"></span>
                                    </div>
                                    
                                </div>
                                <div class="d-flex justify-content-between">
                                    <h5 class="" class="mb-0">$120.40</h5>
                                    <div class="text-end" >

                                        <a href="<?php echo e(route('cart')); ?>" class="btn btn-primary"><i class="bx bx-shopping-bag fs-22"></i></a>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </a>
                </div>
                <div class="col-lg-3 col-md-6">
                    <a href="<?php echo e(route('product.details')); ?>">
                        <div class="card">
                            <img class="card-img-top img-fluid" src="assets/images/small/img-1.jpg" alt="Card image cap">
                            <div class="card-body">
                                <h4 class="card-title mb-2">Laptop</h4>
                                <a href="#" class="text-primary d-block">Tommy Hilfiger</a>
                                <div class="d-flex flex-wrap gap-2 align-items-center mt-1">
                                    <div class="text-muted fs-16">
                                        <span class="mdi mdi-star text-warning"></span>
                                        <span class="mdi mdi-star text-warning"></span>
                                        <span class="mdi mdi-star text-warning"></span>
                                        <span class="mdi mdi-star text-warning"></span>
                                        <span class="mdi mdi-star text-warning"></span>
                                    </div>
                                    
                                </div>
                                <div class="d-flex justify-content-between">
                                    <h5 class="" class="mb-0">$120.40</h5>
                                    <div class="text-end" >

                                        <a href="<?php echo e(route('cart')); ?>" class="btn btn-primary"><i class="bx bx-shopping-bag fs-22"></i></a>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </a>
                </div>

            </div>
            <div class="row">
                <div class="col-lg-3 col-md-6">
                    <a href="<?php echo e(route('product.details')); ?>">
                        <div class="card">
                            <img class="card-img-top img-fluid" src="assets/images/small/img-1.jpg" alt="Card image cap">
                            <div class="card-body">
                                <h4 class="card-title mb-2">Laptop</h4>
                                <a href="#" class="text-primary d-block">Tommy Hilfiger</a>
                                <div class="d-flex flex-wrap gap-2 align-items-center mt-1">
                                    <div class="text-muted fs-16">
                                        <span class="mdi mdi-star text-warning"></span>
                                        <span class="mdi mdi-star text-warning"></span>
                                        <span class="mdi mdi-star text-warning"></span>
                                        <span class="mdi mdi-star text-warning"></span>
                                        <span class="mdi mdi-star text-warning"></span>
                                    </div>
                                    
                                </div>
                                <div class="d-flex justify-content-between">
                                    <h5 class="" class="mb-0">$120.40</h5>
                                    <div class="text-end" >

                                        <a href="<?php echo e(route('cart')); ?>" class="btn btn-primary"><i class="bx bx-shopping-bag fs-22"></i></a>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </a>
                </div>
                <div class="col-lg-3 col-md-6">
                    <a href="<?php echo e(route('product.details')); ?>">
                        <div class="card">
                            <img class="card-img-top img-fluid" src="assets/images/small/img-1.jpg" alt="Card image cap">
                            <div class="card-body">
                                <h4 class="card-title mb-2">Laptop</h4>
                                <a href="#" class="text-primary d-block">Tommy Hilfiger</a>
                                <div class="d-flex flex-wrap gap-2 align-items-center mt-1">
                                    <div class="text-muted fs-16">
                                        <span class="mdi mdi-star text-warning"></span>
                                        <span class="mdi mdi-star text-warning"></span>
                                        <span class="mdi mdi-star text-warning"></span>
                                        <span class="mdi mdi-star text-warning"></span>
                                        <span class="mdi mdi-star text-warning"></span>
                                    </div>
                                    
                                </div>
                                <div class="d-flex justify-content-between">
                                    <h5 class="" class="mb-0">$120.40</h5>
                                    <div class="text-end" >

                                        <a href="<?php echo e(route('cart')); ?>" class="btn btn-primary"><i class="bx bx-shopping-bag fs-22"></i></a>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </a>
                </div>
                <div class="col-lg-3 col-md-6">
                    <a href="<?php echo e(route('product.details')); ?>">
                        <div class="card">
                            <img class="card-img-top img-fluid" src="assets/images/small/img-1.jpg" alt="Card image cap">
                            <div class="card-body">
                                <h4 class="card-title mb-2">Laptop</h4>
                                <a href="#" class="text-primary d-block">Tommy Hilfiger</a>
                                <div class="d-flex flex-wrap gap-2 align-items-center mt-1">
                                    <div class="text-muted fs-16">
                                        <span class="mdi mdi-star text-warning"></span>
                                        <span class="mdi mdi-star text-warning"></span>
                                        <span class="mdi mdi-star text-warning"></span>
                                        <span class="mdi mdi-star text-warning"></span>
                                        <span class="mdi mdi-star text-warning"></span>
                                    </div>
                                    
                                </div>
                                <div class="d-flex justify-content-between">
                                    <h5 class="" class="mb-0">$120.40</h5>
                                    <div class="text-end" >

                                        <a href="<?php echo e(route('cart')); ?>" class="btn btn-primary"><i class="bx bx-shopping-bag fs-22"></i></a>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </a>
                </div>
                <div class="col-lg-3 col-md-6">
                    <a href="<?php echo e(route('product.details')); ?>">
                        <div class="card">
                            <img class="card-img-top img-fluid" src="assets/images/small/img-1.jpg" alt="Card image cap">
                            <div class="card-body">
                                <h4 class="card-title mb-2">Laptop</h4>
                                <a href="#" class="text-primary d-block">Tommy Hilfiger</a>
                                <div class="d-flex flex-wrap gap-2 align-items-center mt-1">
                                    <div class="text-muted fs-16">
                                        <span class="mdi mdi-star text-warning"></span>
                                        <span class="mdi mdi-star text-warning"></span>
                                        <span class="mdi mdi-star text-warning"></span>
                                        <span class="mdi mdi-star text-warning"></span>
                                        <span class="mdi mdi-star text-warning"></span>
                                    </div>
                                    
                                </div>
                                <div class="d-flex justify-content-between">
                                    <h5 class="" class="mb-0">$120.40</h5>
                                    <div class="text-end" >

                                        <a href="<?php echo e(route('cart')); ?>" class="btn btn-primary"><i class="bx bx-shopping-bag fs-22"></i></a>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </a>
                </div>

            </div>
            <div class="row">
                <div class="col-lg-3 col-md-6">
                    <a href="<?php echo e(route('product.details')); ?>">
                        <div class="card">
                            <img class="card-img-top img-fluid" src="assets/images/small/img-1.jpg" alt="Card image cap">
                            <div class="card-body">
                                <h4 class="card-title mb-2">Laptop</h4>
                                <a href="#" class="text-primary d-block">Tommy Hilfiger</a>
                                <div class="d-flex flex-wrap gap-2 align-items-center mt-1">
                                    <div class="text-muted fs-16">
                                        <span class="mdi mdi-star text-warning"></span>
                                        <span class="mdi mdi-star text-warning"></span>
                                        <span class="mdi mdi-star text-warning"></span>
                                        <span class="mdi mdi-star text-warning"></span>
                                        <span class="mdi mdi-star text-warning"></span>
                                    </div>
                                    
                                </div>
                                <div class="d-flex justify-content-between">
                                    <h5 class="" class="mb-0">$120.40</h5>
                                    <div class="text-end" >

                                        <a href="<?php echo e(route('cart')); ?>" class="btn btn-primary"><i class="bx bx-shopping-bag fs-22"></i></a>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </a>
                </div>
                <div class="col-lg-3 col-md-6">
                    <a href="<?php echo e(route('product.details')); ?>">
                        <div class="card">
                            <img class="card-img-top img-fluid" src="assets/images/small/img-1.jpg" alt="Card image cap">
                            <div class="card-body">
                                <h4 class="card-title mb-2">Laptop</h4>
                                <a href="#" class="text-primary d-block">Tommy Hilfiger</a>
                                <div class="d-flex flex-wrap gap-2 align-items-center mt-1">
                                    <div class="text-muted fs-16">
                                        <span class="mdi mdi-star text-warning"></span>
                                        <span class="mdi mdi-star text-warning"></span>
                                        <span class="mdi mdi-star text-warning"></span>
                                        <span class="mdi mdi-star text-warning"></span>
                                        <span class="mdi mdi-star text-warning"></span>
                                    </div>
                                    
                                </div>
                                <div class="d-flex justify-content-between">
                                    <h5 class="" class="mb-0">$120.40</h5>
                                    <div class="text-end" >

                                        <a href="<?php echo e(route('cart')); ?>" class="btn btn-primary"><i class="bx bx-shopping-bag fs-22"></i></a>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </a>
                </div>
                <div class="col-lg-3 col-md-6">
                    <a href="<?php echo e(route('product.details')); ?>">
                        <div class="card">
                            <img class="card-img-top img-fluid" src="assets/images/small/img-1.jpg" alt="Card image cap">
                            <div class="card-body">
                                <h4 class="card-title mb-2">Laptop</h4>
                                <a href="#" class="text-primary d-block">Tommy Hilfiger</a>
                                <div class="d-flex flex-wrap gap-2 align-items-center mt-1">
                                    <div class="text-muted fs-16">
                                        <span class="mdi mdi-star text-warning"></span>
                                        <span class="mdi mdi-star text-warning"></span>
                                        <span class="mdi mdi-star text-warning"></span>
                                        <span class="mdi mdi-star text-warning"></span>
                                        <span class="mdi mdi-star text-warning"></span>
                                    </div>
                                    
                                </div>
                                <div class="d-flex justify-content-between">
                                    <h5 class="" class="mb-0">$120.40</h5>
                                    <div class="text-end" >

                                        <a href="<?php echo e(route('cart')); ?>" class="btn btn-primary"><i class="bx bx-shopping-bag fs-22"></i></a>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </a>
                </div>
                <div class="col-lg-3 col-md-6">
                    <a href="<?php echo e(route('product.details')); ?>">
                        <div class="card">
                            <img class="card-img-top img-fluid" src="assets/images/small/img-1.jpg" alt="Card image cap">
                            <div class="card-body">
                                <h4 class="card-title mb-2">Laptop</h4>
                                <a href="#" class="text-primary d-block">Tommy Hilfiger</a>
                                <div class="d-flex flex-wrap gap-2 align-items-center mt-1">
                                    <div class="text-muted fs-16">
                                        <span class="mdi mdi-star text-warning"></span>
                                        <span class="mdi mdi-star text-warning"></span>
                                        <span class="mdi mdi-star text-warning"></span>
                                        <span class="mdi mdi-star text-warning"></span>
                                        <span class="mdi mdi-star text-warning"></span>
                                    </div>
                                    
                                </div>
                                <div class="d-flex justify-content-between">
                                    <h5 class="" class="mb-0">$120.40</h5>
                                    <div class="text-end" >

                                        <a href="<?php echo e(route('cart')); ?>" class="btn btn-primary"><i class="bx bx-shopping-bag fs-22"></i></a>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </a>
                </div>

            </div>
        </div>
        <!-- end container -->
    </section>
    <!-- end blog -->
   
            </div>
        </div>
    </div>



<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
            <!--Swiper slider js-->
            <script src="<?php echo e(asset('assets/libs/swiper/swiper-bundle.min.js')); ?>"></script>
            <!-- ecommerce product details init -->
            <script src="<?php echo e(asset('assets/js/pages/ecommerce-product-details.init.js')); ?>"></script>         
<?php $__env->stopPush(); ?>
<?php echo $__env->make('frontend.layout.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\project\LN\sentimantal\resources\views/frontend/pages/ecommerce/products.blade.php ENDPATH**/ ?>