<?php

use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider and all of them will
| be assigned to the "web" middleware group. Make something great!
|
*/

// Route::get('/', function () {
//     return view('welcome');
// });

Route::get('/', function () {
    return view('frontend.pages.home');
})->name('home');
Route::get('/cart', function () {
    return view('frontend.pages.ecommerce.cart');
})->name('cart');
Route::get('/all-product', function () {
    return view('frontend.pages.ecommerce.products');
})->name('products');
Route::get('/checkout', function () {
    return view('frontend.pages.ecommerce.checkout');
})->name('checkout');
Route::get('/product-details', function () {
    return view('frontend.pages.home');
})->name('product.details');